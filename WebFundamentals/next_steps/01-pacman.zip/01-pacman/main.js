$(document).ready(function(){
    // let w=window.innerWidth/1.25;
    // let h=window.innerHeight/1.25;

    // new Game("Pacman",w,h);
});
