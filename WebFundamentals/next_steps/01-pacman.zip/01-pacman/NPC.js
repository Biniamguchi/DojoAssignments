function NPC(){
    var self   = new Moving();
    self.hp    = 1;
    self.alive = true;

    return self;
}
